TwoFly — portable desk
======================

Windows 10 / 11, 64-bit.
Double-click TwoFly.exe. No install. No Community folder. No sim connection.

Does not run on Mac or Linux.

The eight pilot marks are already inside the program.

Pilot name, mark, hangar, money, XP, log, and stamps save on this machine
(%LOCALAPPDATA%\TwoFly\store.json) and come back when you reopen the exe.

Stamps and postcards (optional, later)
--------------------------------------
If you add a stamps folder next to TwoFly.exe, unlocked tiles load those pictures:

  stamps/
    states/       NM.png, TX.png, …
    countries/    US.png, ID.png, …
    landmarks/    shiprock.png, …
    cities/       nyc.png, jkt.png, …   (800x600 postcards)

If the window does not open, use Microsoft Edge (already on Windows 10/11)
or Google Chrome.
